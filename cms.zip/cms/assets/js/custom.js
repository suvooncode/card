$(document).ready(function () {
	var swiper = new Swiper('.card-slider .swiper-container', {
      spaceBetween: 0,
      centeredSlides: true,
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
    });

});
