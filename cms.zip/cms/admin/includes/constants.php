<?php
define("DOMAIN_NAME_PATH", "http://localhost/pr/admin/");
define("DOMAIN_WEBSITE", "http://localhost/pr/web/");
define("DOMAIN_WEBSITE_FOR_POST", "http://localhost/pr/web/post/");
define("RIGHT_PANEL_STORY_LIST", "commoninclude/right_panel_story_list.php");

//DEFINE PAGINATION LIMIT OF LISTING PAGE
define("PAGELIMIT", "4");
define("LINKPERPAGE", "5");
define("IDHASH", "=v5K@");
define("ADMIN_EMAIL", "admin@gmail.com");


define("MAILCURLLINK","http://localhost/crm/email/send_mail.php");
define("ADMINMAILTOSENT","shovan.ghorai@tdtl.world");
define("WEBLINK","http://localhost/crm/");
define("ULTIMATESTAGE","5");

//define("SENDCERTIFICATE","http://localhost/crm/email/sendcertificate.php");
//define("GENERATECERTIFICATE","http://localhost/cr/generatecertificate/generatecertificate.php");
?>
