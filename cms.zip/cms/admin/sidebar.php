<div class="deznav">
            <div class="deznav-scroll">
				<ul class="metismenu" id="menu">

                    <!-- <li><a class="has-arrow ai-icon" href="javascript:void()" aria-expanded="true">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Menu</span>
						</a>
                        <ul aria-expanded="true">
							<li><a href="#">Main Content</a></li>
							<li><a href="#">Recent cards</a></li>
							<li><a href="#">Information</a></li>
							<li><a href="#">Process</a></li>
							<li><a href="#">Collection</a></li>
						</ul>
                    </li>  -->

					<li>
						<a class="" href="main_content.php" aria-expanded="false">
							<i class="flaticon-381-networking"></i>
							<span class="nav-text">Main Content</span>
						</a>
					</li>
					<li>
						<a class="" href="recent_cards.php" aria-expanded="false">
							<i class="flaticon-381-folder-14"></i>
							<span class="nav-text">Recent cards</span>
						</a>
					</li>
					<li>
						<a class="" href="information.php" aria-expanded="false">
							<i class="flaticon-381-notepad"></i>
							<span class="nav-text">Information</span>
						</a>
					</li>
					<li>
						<a class="" href="process.php" aria-expanded="false">
							<i class="flaticon-381-route"></i>
							<span class="nav-text">Process</span>
						</a>
					</li>
					<li>
						<a class="" href="collection.php" aria-expanded="false">
							<i class="flaticon-381-newspaper"></i>
							<span class="nav-text">Collection</span>
						</a>
					</li>
					<li>
						<a class="" href="add_card.php" aria-expanded="false">
							<i class="flaticon-381-film-strip-1"></i>
							<span class="nav-text">Add Card</span>
						</a>
					</li>
					<li>
						<a class="" href="users.php" aria-expanded="false">
							<i class="flaticon-381-user-9"></i>
							<span class="nav-text">Users</span>
						</a>
					</li>
					<li>
						<a class="" href="users_card.php" aria-expanded="false">
							<i class="flaticon-381-success"></i>
							<span class="nav-text">Users Card Collection</span>
						</a>
					</li>
					
                   
                </ul>

				<!-- <div class="add-menu-sidebar">
					<img src="images/calendar.png" alt="" class="mr-3">
					<p class="	font-w500 mb-0">View your Calendar</p>
				</div> -->
				<!-- <div class="copyright">
					<p><strong>Card</strong> © 2022 All Rights Reserved</p>
					<p>Made with <span class="heart"></span></p>
				</div> -->
	</div>
</div>