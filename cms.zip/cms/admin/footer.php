<div class="footer">
            <div class="copyright">
                <p>Copyright © Designed &amp; Developed by </p>
            </div>
        </div>